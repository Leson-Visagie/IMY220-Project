import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Splash from './pages/Splash.js';
import Home from './pages/Home.js';
import Profile from './pages/Profile.js';
import Project from './pages/Project.js';
import Header from './components/Header.js';
import Admin from './pages/Admin.js';
import Search from './pages/Search.js'; 

function App() {
  const [uid, setUid] = React.useState(localStorage.uid);
  

  const [currentUser, setCurrentUser] = React.useState(null);

  React.useEffect(() => {
    if (uid) {
      fetch('/api/users/me', { credentials: 'include' })
        .then(r => r.ok ? r.json() : null)
        .then(user => {
          if (user) {
          
            if (user.email === 'admin@tuks.ac.za') {
              user.isAdmin = true;
            }
            setCurrentUser(user);
          } else {
          
            logout();
          }
        });
    } else {
      setCurrentUser(null);
    }
  }, [uid]);

  const login = (id) => { 
    localStorage.uid = id; 
    setUid(id); 
  };
  
  const logout = () => { 
    fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
    delete localStorage.uid; 
    setUid(null); 
    setCurrentUser(null);
  };

  if (!currentUser && uid) {
    return <div className="min-h-screen bg-gray-50 dark:bg-gray-900" />;
  }

  
  if (!currentUser) {
    return <Splash login={login} />;
  }

 
  return (
    <BrowserRouter basename="/">
      <div className="min-h-screen flex flex-col font-sans bg-gray-100 dark:bg-gray-950 text-gray-900 dark:text-gray-100">
        <Header logout={logout} currentUser={currentUser} />
        <div className="flex-grow">
          <Routes>
            <Route path="/" element={<Navigate to="/home" />} />
            <Route path="/home" element={<Home />} />
            <Route 
              path="/profile/:id" 
              element={<Profile currentUser={currentUser} logout={logout} />}
            />
            <Route 
              path="/project/:id" 
              element={<Project currentUser={currentUser} />}
            />
            <Route path="/search" element={<Search />} />
            
            {currentUser.isAdmin && <Route path="/admin" element={<Admin />} />}
            
            <Route path="*" element={<Navigate to="/home" />} />
          </Routes>
        </div>
      </div>
    </BrowserRouter>
  );
}
export default App;