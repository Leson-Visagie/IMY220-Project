import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import FriendRequests from '../components/FriendRequests.js'; 

export default function Profile({ currentUser, logout }) {
  const { id } = useParams();
  const [user, setUser] = useState(null);
  const [projects, setProjects] = useState([]);
  const [friends, setFriends] = useState([]);
  const [edit, setEdit] = useState(false);
  const [form, setForm] = useState({ name: '', bio: '', work: '', contact: '' });
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const isMe = id === 'me' || id === currentUser._id;
  const profileId = isMe ? currentUser._id : id;

  const sendRequest = async () => {
    await fetch(`/api/users/friend/request/${id}`, { method: 'POST', credentials: 'include' });
    setSent(true);
  };

  useEffect(() => {
    setLoading(true);
    Promise.all([
      fetch(`/api/users/${profileId}`, { credentials: 'include' }).then(r => r.ok ? r.json() : null),
      fetch(`/api/projects?user=${profileId}`, { credentials: 'include' }).then(r => r.ok ? r.json() : []),
      fetch(`/api/users/${profileId}/friends`, { credentials: 'include' }).then(r => r.ok ? r.json() : [])
    ]).then(([userData, projData, friendData]) => {
      setUser(userData);
      setForm({ name: userData.name, bio: userData.bio || '', work: userData.work || '', contact: userData.contact || '' });
      setProjects(projData);
      setFriends(friendData);
      setLoading(false);
    });
  }, [profileId]);

  const save = async () => {
    await fetch('/api/users/me', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
      credentials: 'include'
    });
    setUser(u => ({ ...u, ...form }));
    setEdit(false);
  };

  const deleteProfile = async () => {
    if (window.confirm('Are you sure you want to delete your profile? This will also delete all projects you own. This action cannot be undone.')) {
      await fetch('/api/users/me', { method: 'DELETE', credentials: 'include' });
      logout();
      navigate('/');
    }
  };

  if (loading || !user) {
    return <main className="max-w-7xl mx-auto p-6">Loading...</main>;
  }

  const canViewFullProfile = isMe || user.isFriend;

  return (
    <main className="max-w-7xl mx-auto p-6 space-y-8">
     
      {isMe && <FriendRequests />}
      
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 flex flex-col md:flex-row items-center gap-8">
        <img 
          src={user.image || `https://api.dicebear.com/7.x/pixel-art/svg?seed=${user._id}`} 
          alt="Profile"
          className="w-32 h-32 rounded-full ring-4 ring-indigo-500 dark:ring-indigo-400"
        />
        <div className="flex-grow">
          <h1 className="text-4xl font-extrabold text-gray-900 dark:text-white">{user.name}</h1>
          
          {!canViewFullProfile && (
            <p className="text-lg text-gray-500 dark:text-gray-400 mt-2">
              You must be friends to view this profile.
            </p>
          )}

          {!isMe && !user.isFriend && !sent && (
            <button onClick={sendRequest} className="btn-primary mt-4">
              Send Friend Request
            </button>
          )}
         
          {!isMe && !user.isFriend && sent && (
            <span className="text-green-600 font-medium mt-4 block">Request Sent</span>
          )}

        </div>
        {isMe && !edit && (
          <button onClick={() => setEdit(true)} className="btn-secondary ml-auto">Edit Profile</button>
        )}
        {isMe && edit && (
          <button onClick={deleteProfile} className="btn-danger ml-auto">
            Delete Profile
          </button>
        )}
      </div>

      {canViewFullProfile ? (
        <>
          {isMe && edit && (
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
              <h2 className="text-2xl font-bold mb-4">Edit Profile</h2>
              <div className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Name</label>
                  <input id="name" type="text" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className="form-input" />
                </div>
                <div>
                  <label htmlFor="bio" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Bio</label>
                  <textarea id="bio" value={form.bio} onChange={e => setForm(f => ({ ...f, bio: e.target.value }))} className="form-input" />
                </div>
                <div>
                  <label htmlFor="work" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Work</label>
                  <input id="work" type="text" value={form.work} onChange={e => setForm(f => ({ ...f, work: e.target.value }))} className="form-input" />
                </div>
                <div>
                  <label htmlFor="contact" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Contact</label>
                  <input id="contact" type="text" value={form.contact} onChange={e => setForm(f => ({ ...f, contact: e.target.value }))} className="form-input" />
                </div>
              </div>
              <button onClick={save} className="btn-primary mt-4">Save Changes</button>
              <button onClick={() => setEdit(false)} className="btn-secondary ml-2">Cancel</button>
            </div>
          )}

          {!edit && (
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
              <h2 className="text-2xl font-bold mb-4">Details</h2>
              {user.bio && <p><strong>Bio:</strong> {user.bio}</p>}
              {user.work && <p><strong>Work:</strong> {user.work}</p>}
              {user.contact && <p><strong>Contact:</strong> {user.contact}</p>}
            </div>
          )}

          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
            <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">Projects</h2>
            {projects.length === 0 ? (
              <p className="text-gray-500 dark:text-gray-400">
                {isMe ? 'You have no projects yet.' : `${user.name} has no projects.`}
              </p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {projects.map(p => (
                  <Link 
                    key={p._id} 
                    to={`/project/${p._id}`} 
                    className="block p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:shadow-md dark:hover:bg-gray-700/50 transition-all"
                  >
                    <h3 className="font-semibold text-indigo-600 dark:text-indigo-400">{p.name}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-300 truncate">{p.description}</p>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {p.hashtags?.map(tag => (
                        <Link 
                          key={tag} 
                          to={`/search?q=${tag}`} 
                          onClick={e => e.stopPropagation()}
                          className="text-xs px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200 hover:bg-indigo-200"
                        >
                          #{tag}
                        </Link>
                      ))}
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="text-center p-10 bg-white dark:bg-gray-800 rounded-xl shadow-lg">
          <h2 className="text-xl font-semibold">Profile is Private</h2>
          <p className="text-gray-500 dark:text-gray-400">Send a friend request to see {user.name}'s details and projects.</p>
        </div>
      )}
    </main>
  );
}