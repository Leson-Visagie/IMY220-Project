import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';

export default function Search() {
  const [searchParams] = useSearchParams();
  const [results, setResults] = useState({ users: [], projects: [] });
  const [loading, setLoading] = useState(true);
  const query = searchParams.get('q');

  useEffect(() => {
    if (query) {
      setLoading(true);
      fetch(`/api/search?q=${encodeURIComponent(query)}`, { credentials: 'include' })
        .then(r => r.ok ? r.json() : { users: [], projects: [] })
        .then(data => {
          setResults(data);
          setLoading(false);
        });
    }
  }, [query]);

  if (loading) {
    return <main className="max-w-7xl mx-auto p-6"><h1 className="text-3xl font-bold">Searching...</h1></main>;
  }

  return (
    <main className="max-w-7xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6 text-gray-900 dark:text-white">
        Search Results for: <span className="text-indigo-600 dark:text-indigo-400">"{query}"</span>
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
 
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
          <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">Users</h2>
          {results.users.length === 0 ? (
            <p className="text-gray-500 dark:text-gray-400">No users found.</p>
          ) : (
            <div className="space-y-3">
              {results.users.map(user => (
                <Link 
                  key={user._id} 
                  to={`/profile/${user._id}`} 
                  className="block p-3 bg-gray-50 dark:bg-gray-700 rounded-md hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                >
                  <span className="font-semibold text-indigo-600 dark:text-indigo-400">{user.name}</span>
                  <span className="text-sm text-gray-500 dark:text-gray-400 ml-2">{user.email}</span>
                </Link>
              ))}
            </div>
          )}
        </div>

      
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
          <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">Projects</h2>
          {results.projects.length === 0 ? (
            <p className="text-gray-500 dark:text-gray-400">No projects found.</p>
          ) : (
            <div className="space-y-3">
              {results.projects.map(proj => (
                <Link 
                  key={proj._id} 
                  to={`/project/${proj._id}`} 
                  className="block p-3 bg-gray-50 dark:bg-gray-700 rounded-md hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                >
                  <h3 className="font-semibold text-indigo-600 dark:text-indigo-400">{proj.name}</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300 truncate">{proj.description}</p>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </main>
  );
}