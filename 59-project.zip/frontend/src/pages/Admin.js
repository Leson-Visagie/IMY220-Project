import React, { useState, useEffect } from 'react';


function AdminSection({ title, children }) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
      <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white border-b pb-2 border-gray-200 dark:border-gray-700">
        {title}
      </h2>
      {children}
    </div>
  );
}

export default function Admin() {
  const [users, setUsers] = useState([]);
  const [projects, setProjects] = useState([]);
  const [types, setTypes] = useState([]);
  const [newType, setNewType] = useState('');

 
  useEffect(() => {
    fetch('/api/admin/users', { credentials: 'include' })
      .then(r => r.ok && r.json())
      .then(setUsers);
    
    fetch('/api/admin/projects', { credentials: 'include' })
      .then(r => r.ok && r.json())
      .then(setProjects);

    fetch('/api/admin/types', { credentials: 'include' })
      .then(r => r.ok && r.json())
      .then(setTypes);
  }, []);


  const deleteUser = async (id) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      await fetch(`/api/admin/users/${id}`, { method: 'DELETE', credentials: 'include' });
      setUsers(users.filter(u => u._id !== id));
    }
  };


  const deleteProject = async (id) => {
    if (window.confirm('Are you sure you want to delete this project?')) {
      await fetch(`/api/admin/projects/${id}`, { method: 'DELETE', credentials: 'include' });
      setProjects(projects.filter(p => p._id !== id));
    }
  };


  const addType = async (e) => {
    e.preventDefault();
    const res = await fetch('/api/admin/types', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: newType }),
      credentials: 'include'
    });
    if (res.ok) {
      const addedType = await res.json();
      setTypes([...types, addedType]);
      setNewType('');
    }
  };

  return (
    <main className="max-w-7xl mx-auto p-6 space-y-8">
      <h1 className="text-4xl font-extrabold text-gray-900 dark:text-white">Admin Dashboard</h1>


      <AdminSection title="Manage Project Types">
        <form onSubmit={addType} className="flex gap-4 mb-4">
          <input 
            type="text"
            value={newType}
            onChange={e => setNewType(e.target.value)}
            placeholder="New project type (e.g., 'Game')"
            className="form-input flex-grow"
          />
          <button type="submit" className="btn-primary">Add Type</button>
        </form>
        <ul className="list-disc list-inside">
          {types.map(t => (
            <li key={t._id} className="text-gray-700 dark:text-gray-300">{t.name}</li>
          ))}
        </ul>
      </AdminSection>


      <AdminSection title="Manage Users">
        <div className="space-y-3">
          {users.map(user => (
            <div key={user._id} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700 rounded-md">
              <div>
                <span className="font-semibold">{user.name}</span>
                <span className="text-sm text-gray-500 dark:text-gray-400 ml-2">{user.email}</span>
              </div>
              <button onClick={() => deleteUser(user._id)} className="btn-danger-sm">
                Delete
              </button>
            </div>
          ))}
        </div>
      </AdminSection>

      <AdminSection title="Manage Projects">
        <div className="space-y-3">
          {projects.map(proj => (
            <div key={proj._id} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700 rounded-md">
              <div>
                <span className="font-semibold">{proj.name}</span>
                <span className="text-sm text-gray-500 dark:text-gray-400 ml-2">(Type: {proj.type})</span>
              </div>
              <button onClick={() => deleteProject(proj._id)} className="btn-danger-sm">
                Delete
              </button>
            </div>
          ))}
        </div>
      </AdminSection>
    </main>
  );
}