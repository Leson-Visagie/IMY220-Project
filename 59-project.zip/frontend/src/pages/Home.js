import LiveFeed from '../components/LiveFeed.js';
export default function Home() {
  return <LiveFeed />;
}