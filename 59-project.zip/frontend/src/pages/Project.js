

import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import FileUpload from '../components/FileUpload.js';
import Discussion from '../components/Discussion.js';



function ProjectManagement({ proj, members, setMembers, setProj }) {
  const [addEmail, setAddEmail] = useState('');

  const addMember = async (e) => {
    e.preventDefault();
    const res = await fetch(`/api/projects/${proj._id}/members`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: addEmail }),
      credentials: 'include'
    });
    if (res.ok) {
      const newMember = await res.json();
      setMembers([...members, newMember]);
      setAddEmail('');
    } else {
      alert((await res.json()).error);
    }
  };

  const removeMember = async (id) => {
    if (window.confirm('Are you sure?')) {
      await fetch(`/api/projects/${proj._id}/members/${id}`, { method: 'DELETE', credentials: 'include' });
      setMembers(members.filter(m => m._id !== id));
    }
  };
  
  const relinquish = async (id) => {
    if (window.confirm('Make this user the new owner? This cannot be undone.')) {
      await fetch(`/api/projects/${proj._id}/owner`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: id }),
        credentials: 'include'
      });
      setProj(p => ({ ...p, owner: id }));
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
      <h3 className="text-lg font-semibold mb-4">Project Management</h3>
      <form onSubmit={addMember} className="mb-6">
        <label htmlFor="add-member" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Add Member (must be your friend)</label>
        <div className="flex gap-2">
          <input 
            id="add-member"
            type="email"
            value={addEmail}
            onChange={e => setAddEmail(e.target.value)}
            placeholder="friend@email.com"
            className="form-input flex-grow"
          />
          <button type="submit" className="btn-secondary">Add</button>
        </div>
      </form>
      <h4 className="font-semibold mb-2">Members</h4>
      <div className="space-y-2">
        {members.map(m => (
          <div key={m._id} className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-700 rounded">
            <span>{m.name} {m._id === proj.owner && '(Owner)'}</span>
            {proj.isOwner && m._id !== proj.owner && (
              <div className="flex gap-2">
                <button onClick={() => relinquish(m._id)} className="btn-secondary-sm">Make Owner</button>
                <button onClick={() => removeMember(m._id)} className="btn-danger-sm">Remove</button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}


export default function Project({ currentUser }) {
  const { id } = useParams();
  const [proj, setProj] = useState(null);
  const [members, setMembers] = useState([]);
  const [msg, setMsg] = useState('');
  const [version, setVersion] = useState('');
  const [uploads, setUploads] = useState([]);
  
  const isMember = proj?.members.map(String).includes(String(currentUser._id));
  const isOwner = proj?.owner === currentUser._id;
  const canCheckIn = proj?.status === 'out' && proj?.holderId === currentUser._id;
  const canCheckOut = proj?.status === 'in' && isMember;

  const loadData = () => {
    fetch(`/api/projects/${id}`, { credentials: 'include' })
      .then(r => r.json())
      .then(async (pData) => { 
        if (pData.activity && pData.activity.length > 0) {
          const userIds = [...new Set(pData.activity.map(a => a.user))];
          const userPromises = userIds.map(uid =>
            fetch(`/api/users/${uid}`, { credentials: 'include' }).then(r => r.ok ? r.json() : { _id: uid, name: 'Unknown' })
          );
          const users = await Promise.all(userPromises);
          const userMap = users.reduce((acc, user) => {
            acc[user._id] = user.name;
            return acc;
          }, {});
          pData.activity.forEach(a => {
            a.userName = userMap[a.user] || 'Unknown';
          });
        }
        pData.isOwner = pData.owner === currentUser._id;
        pData.isMember = pData.members.map(String).includes(String(currentUser._id));
        setProj(pData);
        setVersion(pData.version || '1.0.0');
      });
    
    fetch(`/api/projects/${id}/members`, { credentials: 'include' })
      .then(r => r.json())
      .then(setMembers);
  };
  
  useEffect(loadData, [id, currentUser._id]);

  const checkout = async () => {
    await fetch(`/api/projects/${id}/checkout`, { method: 'POST', credentials: 'include' });
    window.open(`/api/projects/${id}/download`);
    loadData();
  };

  const checkin = async e => {
    e.preventDefault();
    const fd = new FormData();
    uploads.forEach(f => fd.append('files', f));
    fd.append('msg', msg);
    fd.append('version', version);
    await fetch(`/api/projects/${id}/checkin`, { method: 'POST', body: fd, credentials: 'include' });
    alert('Checked in successfully!');
    setUploads([]);
    setMsg('');
    loadData();
  };
  
  if (!proj) return <main className="max-w-7xl mx-auto p-6">Loading...</main>;

  return (
    <main className="max-w-7xl mx-auto p-6 space-y-8">

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
        <h1 className="text-4xl font-extrabold text-gray-900 dark:text-white mb-2">{proj.name}</h1>
        <p className="text-lg text-gray-600 dark:text-gray-300 mb-4">{proj.description}</p>
        <div className="flex flex-wrap gap-2">
          {proj.hashtags?.map(tag => (
            <Link 
              key={tag} 
              to={`/search?q=${tag}`} 
              className="text-xs px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200 hover:bg-indigo-200"
            >
              #{tag}
            </Link>
          ))}
        </div>
      </div>

      
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h2 className="text-2xl font-bold mb-4">Version Control</h2>
        <div className="flex items-center gap-4">
          {canCheckOut && (
            <button onClick={checkout} className="btn-primary">
              Check Out Project
            </button>
          )}
          
          {!isMember && proj.status === 'in' && (
            <p className="text-gray-500">Join the project to check it out.</p>
          )}
          
          {proj.status === 'out' && !canCheckIn && (
            <p className="p-3 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200 rounded-lg">
              Currently checked out by {proj.holderName}
            </p>
          )}

          <a 
            href={`/api/projects/${id}/download`} 
            target="_blank" 
            rel="noreferrer"
            className="btn-secondary"
          >
            Download .zip
          </a>
        </div>
        
        {canCheckIn && (
          <form onSubmit={checkin} className="mt-6 p-4 border-t dark:border-gray-700 space-y-4">
            <h3 className="text-xl font-semibold">Check In Project</h3>
            <FileUpload onChange={e => setUploads(Array.from(e.target.files))} />
            <input 
              type="text" 
              placeholder="New version (e.g., 1.1.0)" 
              value={version} 
              onChange={e => setVersion(e.target.value)} 
              className="form-input w-full"
            />
            <textarea 
              placeholder="Check-in message..." 
              value={msg} 
              onChange={e => setMsg(e.target.value)} 
              className="form-input w-full"
              rows="3"
            />
            <button type="submit" className="btn-primary">Check In</button>
          </form>
        )}
      </div>

    
      <Discussion projectId={id} />

      {isMember && (
        <ProjectManagement 
          proj={proj} 
          members={members}
          setMembers={setMembers}
          setProj={setProj}
        />
      )}

      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
          <h3 className="text-lg font-semibold mb-4">Project Activity</h3>
          <div className="space-y-4">
            {(proj.activity || []).sort((a, b) => new Date(b.at) - new Date(a.at)).map((a, i) => (
              <div 
                key={i}
                className="border-b last:border-b-0 pb-3 last:pb-0 border-gray-200 dark:border-gray-700"
              >
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-medium text-gray-900 dark:text-white">{a.userName}</span>
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    {new Date(a.at).toLocaleString()}
                  </span>
                  {a.version && (
                    <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200">
                      v{a.version}
                    </span>
                  )}
                </div>
                <p className="text-gray-700 dark:text-gray-300">{a.msg}</p>
                {a.files?.length > 0 && (
                  <div className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                    Files: {a.files.join(', ')}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
    </main>
  );
}