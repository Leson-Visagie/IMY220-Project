import React, { useState } from 'react';
import LoginForm from '../components/LoginForm.js';
import RegisterForm from '../components/RegisterForm.js';

export default function Splash({ login }) {
  const [showReg, setShowReg] = useState(false);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-100 to-purple-100 dark:from-gray-900 dark:to-indigo-900 px-4">
      <div className="w-full max-w-md">
        <h1 className="text-5xl font-extrabold text-center text-indigo-600 dark:text-indigo-400 mb-2">CodeHub</h1>
        <p className="text-center text-gray-600 dark:text-gray-300 mb-8">Version control for coders.</p>

        {showReg ? (
          <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur rounded-2xl shadow-lg p-6">
            <RegisterForm login={login} />
            <p className="text-center text-sm mt-4 text-gray-600 dark:text-gray-400">
              Already have an account?{' '}
              <button onClick={() => setShowReg(false)} className="text-indigo-600 hover:underline">Login</button>
            </p>
          </div>
        ) : (
          <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur rounded-2xl shadow-lg p-6">
            <LoginForm login={login} />
            <p className="text-center text-sm mt-4 text-gray-600 dark:text-gray-400">
              New here?{' '}
              <button onClick={() => setShowReg(true)} className="text-indigo-600 hover:underline">Register</button>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}