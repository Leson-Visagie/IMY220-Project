import React from 'react';

export default function ProjectCard({ project }) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">{project.name}</h3>
      {project.description && (
        <p className="text-gray-600 dark:text-gray-300 text-sm">{project.description}</p>
      )}
      <div className="mt-4 flex items-center justify-between">
        <span className="text-sm text-indigo-600 dark:text-indigo-400 font-medium">
          Version: {project.version || '1.0.0'}
        </span>
        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
          project.status === 'in' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' : 
          'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
        }`}>
          {project.status === 'in' ? 'Available' : 'Checked Out'}
        </span>
      </div>
    </div>
  );
}