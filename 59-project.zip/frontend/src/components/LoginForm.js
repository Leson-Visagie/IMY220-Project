import React from 'react';

export default function LoginForm({ login }) {
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [error, setError] = React.useState(null); 

  const submit = async (e) => {
    e.preventDefault();
    setError(null); 
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
      credentials: 'include'
    });
    if (res.ok) { 
      const { uid } = await res.json(); 
      login(uid); 
    } else {
      setError('Invalid email or password. Please try again.');
    }
  };

  return (
    <form onSubmit={submit} className="space-y-6">
      <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white">Login</h2>
      {error && (
        <div className="p-3 bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-200 rounded-lg text-sm">
          {error}
        </div>
      )}

      <div>
    
        <label htmlFor="login-email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Email
        </label>
        <input 
          id="login-email" 
          type="email" 
          required 
          value={email} 
          onChange={e => setEmail(e.target.value)}
          className="form-input" 
        />
      </div>
      <div>
    
        <label htmlFor="login-password" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Password
        </label>
        <input 
          id="login-password" 
          type="password" 
          required 
          value={password} 
          onChange={e => setPassword(e.target.value)}
          className="form-input" 
        />
      </div>
      <button type="submit" className="btn-primary w-full">
        Login
      </button>
    </form>
  );
}