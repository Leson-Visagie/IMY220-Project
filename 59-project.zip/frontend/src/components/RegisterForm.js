import React from 'react';

export default function RegisterForm({ login }) {
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [name, setName] = React.useState('');
  

  const submit = async (e) => {
    e.preventDefault();
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, name }),
      credentials: 'include'
    });
   
    if (res.ok) { const { uid } = await res.json(); login(uid); }
  };

  return (
    <form onSubmit={submit} className="space-y-6">
      <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white">Register</h2>
      <div>
       
        <label htmlFor="reg-name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Name
        </label>
        <input 
          id="reg-name" 
          required 
          value={name} 
          onChange={e => setName(e.target.value)}
          className="form-input" 
        />
      </div>
      <div>
      
        <label htmlFor="reg-email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Email
        </label>
        <input 
          id="reg-email" 
          type="email" 
          required 
          value={email} 
          onChange={e => setEmail(e.target.value)}
          className="form-input"
        />
      </div>
      <div>
    
        <label htmlFor="reg-password" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Password
        </label>
        <input 
          id="reg-password" 
          type="password" 
          required 
          value={password} 
          onChange={e => setPassword(e.target.value)}
          className="form-input" 
        />
      </div>
      <button type="submit" className="btn-primary w-full">
        Create Account
      </button>
    </form>
  );
}