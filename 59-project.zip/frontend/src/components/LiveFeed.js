import React, { useEffect, useState } from 'react';

export default function LiveFeed() {
  const [feed, setFeed] = useState([]);
  const [global, setGlobal] = useState(true);

  const load = () => {
    fetch(global ? '/api/activity/global' : '/api/activity/local', { credentials: 'include' })
      .then(r => r.ok ? r.json() : [])
      .then(setFeed);
  };

  useEffect(() => { 
    load(); 
    const t = setInterval(load, 10000); 
    return () => clearInterval(t); 
  }, [global]);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Live Feed</h1>
        <button onClick={() => setGlobal(g => !g)} className="btn-primary">
          {global ? 'Show Local' : 'Show Global'}
        </button>
      </div>

      <div className="grid gap-4">
        {feed.map((a, i) => (
          <div key={i} className="bg-white dark:bg-gray-800 rounded-xl shadow p-4 flex items-start gap-4">
           
            <span className="text-2xl text-indigo-500 font-bold">
              {a.msg.includes('checked out') ? '[OUT]' : a.msg.includes('checked in') ? '[IN]' : '[LOG]'}
            </span>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-medium">{a.userName}</span>
                <span className="text-sm text-gray-500">
                  {new Date(a.at).toLocaleString()}
                </span>
              </div>
              <p className="text-gray-700 dark:text-gray-300">{a.msg}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}