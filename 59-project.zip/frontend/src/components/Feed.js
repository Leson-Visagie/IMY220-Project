import React from 'react';

export default function Feed() {
  const [list, setList] = React.useState([]);

  React.useEffect(() => {
    fetch('/api/activity/global', { credentials: 'include' })
      .then(r => r.json())
      .then(setList)
      .catch(console.error);
  }, []);

  return (
    <div className="feed">
      {list.map((a, i) => (
        <div key={i} className="card">{a.msg}</div>
      ))}
    </div>
  );
}