import React, { useState } from 'react';

export default function FileUpload({ onChange }) {
  const [filenames, setFilenames] = useState([]);
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    setError(null);
    const files = Array.from(e.target.files);
    
    const largeFile = files.find(f => f.size > 5 * 1024 * 1024);
    if (largeFile) {
      setError(`File "${largeFile.name}" is too large. Max 5MB allowed.`);
      e.target.value = null; 
      setFilenames([]);
      onChange({ target: { files: [] } }); 
      return;
    }

    setFilenames(files.map(f => f.name));
    onChange(e); 
  };

  return (
    <div className="w-full">

      <label 
        htmlFor="file-upload" 
        className="form-input cursor-pointer flex items-center justify-center text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-600"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
        </svg>
        <span>Select files (Max 5MB each)</span>
      </label>
      
      
      <input 
        id="file-upload"
        type="file" 
        multiple 
        onChange={handleChange} 
        className="hidden"
      />
      
      
      {error && (
        <p className="text-red-500 text-sm mt-2">{error}</p>
      )}

      {filenames.length > 0 && (
        <div className="mt-2 text-sm text-gray-500 dark:text-gray-400">
          <p className="font-medium">Selected files:</p>
          <ul className="list-disc list-inside">
            {filenames.map(name => <li key={name}>{name}</li>)}
          </ul>
        </div>
      )}
    </div>
  );
}