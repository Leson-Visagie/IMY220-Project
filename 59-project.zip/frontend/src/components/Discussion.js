import React, { useState, useEffect } from 'react';

export default function Discussion({ projectId }) {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [users, setUsers] = useState([]);
  const [showMentions, setShowMentions] = useState(false);
  const [mentionFilter, setMentionFilter] = useState('');
  const [mentionPos, setMentionPos] = useState(null);

  useEffect(() => {

    fetch(`/api/projects/${projectId}/comments`, { credentials: 'include' })
      .then(r => r.json())
      .then(setComments);

    fetch(`/api/projects/${projectId}/members`, { credentials: 'include' })
      .then(r => r.json())
      .then(setUsers);
  }, [projectId]);

  const handleInput = (e) => {
    const text = e.target.value;
    setNewComment(text);

    const lastAtPos = text.lastIndexOf('@');
    if (lastAtPos >= 0 && lastAtPos === text.length - 1) {
      setShowMentions(true);
      setMentionPos(lastAtPos);
      setMentionFilter('');
    } else if (lastAtPos >= 0 && lastAtPos > mentionPos) {
      const afterAt = text.slice(lastAtPos + 1);
      setMentionFilter(afterAt);
    } else {
      setShowMentions(false);
    }
  };

  const selectMention = (user) => {
    const before = newComment.slice(0, mentionPos);
    const after = newComment.slice(mentionPos + 1 + mentionFilter.length);
    setNewComment(`${before}@${user.name} ${after}`);
    setShowMentions(false);
  };

  const addComment = async (e) => {
    e.preventDefault();
    const res = await fetch(`/api/projects/${projectId}/comments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: newComment }),
      credentials: 'include'
    });
    if (res.ok) {
      const comment = await res.json();
      setComments([...comments, comment]);
      setNewComment('');
    }
  };

  const formatComment = (text) => {
    
    text = text.replace(/@(\w+)/g, '<a href="/profile/$1" class="text-blue-600">@$1</a>');
   
    text = text.replace(/#(\w+)/g, '<a href="/search?tag=$1" class="text-indigo-600">#$1</a>');
    return <span dangerouslySetInnerHTML={{ __html: text }} />;
  };

  const filteredUsers = mentionFilter
    ? users.filter(u => u.name.toLowerCase().includes(mentionFilter.toLowerCase()))
    : users;

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
      <h3 className="text-lg font-semibold mb-4">Discussion</h3>
      
      <div className="space-y-4 mb-6">
        {comments.map((c, i) => (
          <div key={i} className="border-b pb-3">
            <div className="flex items-center gap-2 mb-1">
              <span className="font-medium">{c.userName}</span>
              <span className="text-sm text-gray-500">
                {new Date(c.createdAt).toLocaleString()}
              </span>
            </div>
            <p className="text-gray-700 dark:text-gray-300">
              {formatComment(c.text)}
            </p>
          </div>
        ))}
      </div>

      <form onSubmit={addComment} className="relative">
        <textarea
          value={newComment}
          onChange={handleInput}
          placeholder="Add a comment... Use @ to mention users and # for tags"
          className="w-full p-3 border rounded-lg"
          rows="3"
        />
        
        {showMentions && (
          <div className="absolute bottom-full left-0 bg-white dark:bg-gray-700 border rounded-lg shadow-lg max-h-48 overflow-y-auto w-64">
            {filteredUsers.map(u => (
              <button
                key={u._id}
                onClick={() => selectMention(u)}
                className="block w-full text-left px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600"
              >
                {u.name}
              </button>
            ))}
          </div>
        )}

        <button 
          type="submit"
          className="mt-2 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Add Comment
        </button>
      </form>
    </div>
  );
}