import React, { useEffect, useState } from 'react';

export default function FriendRequests() {
  const [list, setList] = useState([]);

  useEffect(() => {
    fetch('/api/users/me/requests', { credentials: 'include' })
      .then(r => r.ok ? r.json() : [])
      .then(setList);
  }, []);

  const respond = async (id, action) => {
    await fetch(`/api/users/friend/respond/${id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action }),
      credentials: 'include'
    });
    setList(l => l.filter(u => u._id !== id));
  };

  if (list.length === 0) return null;

  return (
    <div className="mb-6 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-300 dark:border-yellow-600 rounded-lg p-4">
      <h3 className="font-semibold mb-2">Friend Requests</h3>
      {list.map(u => (
        <div key={u._id} className="flex justify-between items-center mb-2">
          <span>{u.name}</span>
          <div className="flex gap-2">
            <button onClick={() => respond(u._id, 'accept')} className="px-3 py-1 rounded bg-green-600 text-white hover:bg-green-700">Accept</button>
            <button onClick={() => respond(u._id, 'decline')} className="px-3 py-1 rounded bg-gray-400 text-white hover:bg-gray-500">Decline</button>
          </div>
        </div>
      ))}
    </div>
  );
}