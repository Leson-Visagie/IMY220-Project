import { Link, useNavigate } from 'react-router-dom'; 
import ThemeToggle from './ThemeToggle.js';
import React, { useState } from 'react'; 

export default function Header({ logout, currentUser }) { 
  const [query, setQuery] = useState(''); 
  const navigate = useNavigate(); 

 
  const handleSearch = (e) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/search?q=${encodeURIComponent(query)}`);
      setQuery('');
    }
  };

  return (
    <header className="w-full bg-white dark:bg-gray-800 text-gray-900 dark:text-white p-4 shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-8">
         
          <Link to="/home" className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">
            CodeHub
          </Link>
          <nav className="hidden md:flex gap-6 items-center">
            <Link to="/home" className="font-medium text-gray-600 dark:text-gray-300 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">Home</Link>
            <Link to="/profile/me" className="font-medium text-gray-600 dark:text-gray-300 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">Profile</Link>
            
         
            {currentUser.isAdmin && (
              <Link to="/admin" className="font-bold text-yellow-500 hover:text-yellow-400 transition-colors">
                Admin Panel
              </Link>
            )}
          </nav>
        </div>
        

        <form onSubmit={handleSearch} className="flex-grow max-w-xs mx-4">
          <input 
            type="search"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search users & projects..."
            className="form-input w-full" 
          />
        </form>

        <div className="flex items-center gap-4">
          <ThemeToggle />
          <button 
            onClick={logout} 
            className="btn-danger" 
          >
            Logout
          </button>
        </div>
      </div>
    </header>
  );
}