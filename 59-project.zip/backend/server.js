
import express from 'express';
import session from 'express-session';
import { MongoClient } from 'mongodb';
import authRoutes from './routes/auth.js';
import userRoutes from './routes/users.js';
import projectRoutes from './routes/projects.js';
import activityRoutes from './routes/activity.js';
import adminRoutes from './routes/admin.js';
import searchRoutes from './routes/search.js';
import path from 'path';
import { fileURLToPath } from 'url';

const app = express();
app.use(express.json());


app.use(session({ 
  secret: 'imy220',
  resave: false, 
  saveUninitialized: false, 
  cookie: { 
    httpOnly: true 
    
  } 
}));

const client = new MongoClient(process.env.MONGO_URL || 'mongodb://mongo:27017');
await client.connect();
app.locals.db = client.db('imy220');

const __dirname = path.dirname(fileURLToPath(import.meta.url));


app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/activity', activityRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/search', searchRoutes);


const publicPath = path.join(__dirname, 'public');
app.use(express.static(publicPath));


console.log('DEBUG: __dirname =', __dirname);
console.log('DEBUG: publicPath =', publicPath);


app.get('*', (req, res) => {
  res.sendFile(path.join(publicPath, 'index.html'));
});


const port = process.env.PORT || 5000;
app.listen(port, () => {
  console.log(`Backend on :${port}`);
});