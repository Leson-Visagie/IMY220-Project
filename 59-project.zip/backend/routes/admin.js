import express from 'express';
import { ObjectId } from 'mongodb';
import db from '../db/index.js';
const router = express.Router();
const u = id => new ObjectId(id);

router.use(async (req, res, next) => {
  if (req.session?.uid) {
    const user = await db.collection('users').findOne({ _id: toId(req.session.uid) });
    if (user?.email === 'admin@tuks.ac.za') return next();
  }
  return res.status(403).json({ error: 'Admin only' });
});
router.get('/users', async (req, res) => {
  const users = await db.collection('users').find({}, { projection: { password: 0 } }).toArray();
  res.json(users);
});
router.delete('/users/:id', async (req, res) => {
  await db.collection('users').deleteOne({ _id: u(req.params.id) });
  res.json({});
});
router.get('/projects', async (req, res) => {
  const projects = await db.collection('projects').find({}).toArray();
  res.json(projects);
});
router.delete('/projects/:id', async (req, res) => {
  await db.collection('projects').deleteOne({ _id: u(req.params.id) });
  res.json({});
});
router.get('/types', async (req, res) => {
  const types = await db.collection('types').findOne({});
  res.json(types?.list || []);
});
router.post('/types', async (req, res) => {
  await db.collection('types').updateOne({}, { $push: { list: req.body.type } }, { upsert: true });
  res.json({});
});

export default router;