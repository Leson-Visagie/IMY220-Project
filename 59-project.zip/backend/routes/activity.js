import express from 'express';
import db from '../db/index.js';
const router = express.Router();

const toId = id => {
  try { return id instanceof ObjectId ? id : new ObjectId(id); } catch { return null; };
};

async function enrichActivity(list) {
  for (const a of list) {
    const u = await db.collection('users').findOne({ _id: toId(a.user) }, { projection: { name: 1 } });
    a.userName = u?.name || 'Unknown';
  }
  return list;
}

router.get('/global', async (req, res) => {
  const acts = await db.collection('projects').aggregate([
    { $unwind: '$activity' },
    { $sort: { 'activity.at': -1 } },
    { $limit: 50 }
  ]).toArray();
  res.json(await enrichActivity(acts.map(a => a.activity)));
});

router.get('/local', async (req, res) => {
  if (!req.session?.uid) return res.status(401).json([]);
  const acts = await db.collection('projects').aggregate([
    { $match: { members: { $in: [toId(req.session.uid)] } } },
    { $unwind: '$activity' },
    { $sort: { 'activity.at': -1 } }
  ]).toArray();
  res.json(await enrichActivity(acts.map(a => a.activity)));
});

export default router;