import express from 'express';
import { ObjectId } from 'mongodb';
import db from '../db/index.js';
const router = express.Router();

router.post('/register', async (req, res) => {
  const { email, password, name } = req.body;
  const exist = await db.collection('users').findOne({ email });
  if (exist) return res.status(400).json({ msg: 'Exists' });
  const ins = await db.collection('users').insertOne({ email, password, name, image: '', friends: [], createdAt: new Date() });
  req.session.uid = ins.insertedId;
  res.json({ uid: ins.insertedId });
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await db.collection('users').findOne({ email, password });
  if (!user) return res.status(401).json({ msg: 'Invalid' });
  req.session.uid = user._id;
  res.json({ uid: user._id });
});

router.post('/logout', (req, res) => { req.session.destroy(() => res.json({})); });

export default router;