import express from 'express';
import { ObjectId } from 'mongodb';
import db from '../db/index.js';
const router = express.Router();

const u = id => {
  if (!id) return null;
  try {
    if (id instanceof ObjectId) return id;
    return new ObjectId(id);
  } catch (err) {
    return null;
  }
};

router.get('/me', async (req, res) => {
  if (!req.session?.uid) return res.status(401).json({});
  const userId = u(req.session.uid);
  if (!userId) return res.status(401).json({});
  const user = await db.collection('users').findOne({ _id: userId }, { projection: { password: 0 } });
  

  if (user && user.email === 'admin@tuks.ac.za') {
    user.isAdmin = true;
  }
  res.json(user);
});

router.delete('/me', async (req, res) => {
  if (!req.session?.uid) return res.status(401).json({ error: 'Not authenticated' });
  const userId = u(req.session.uid);
  if (!userId) return res.status(401).json({ error: 'Invalid user' });

  try {

    await db.collection('users').deleteOne({ _id: userId });

    
    await db.collection('projects').deleteMany({ owner: userId });

   
    req.session.destroy(err => {
      if (err) return res.status(500).json({ error: 'Could not log out' });
      res.clearCookie('connect.sid'); 
      res.json({ message: 'User and projects deleted' });
    });
  } catch (err) {
    res.status(500).json({ error: 'Error deleting profile' });
  }
});

router.put('/me', async (req, res) => {
  if (!req.session?.uid) return res.status(401).json({});
  const userId = u(req.session.uid);
  if (!userId) return res.status(401).json({});
  await db.collection('users').updateOne({ _id: userId }, { $set: req.body });
  res.json({});
});

router.get('/:id', async (req, res) => {
  const userId = u(req.params.id);
  if (!userId) return res.status(400).json({ error: 'Invalid user ID' });

  const user = await db.collection('users').findOne({ _id: userId }, { projection: { password: 0 } });
  if (!user) return res.status(404).json({ error: 'User not found' });


  if (req.session?.uid) {
    const meId = u(req.session.uid);
   
    const me = await db.collection('users').findOne({ _id: meId }, { projection: { friends: 1 } });
    if (me && me.friends && me.friends.map(String).includes(String(userId))) {
      user.isFriend = true;
    } else {
      user.isFriend = false;
    }
  } else {
    user.isFriend = false; 
  }

  res.json(user);
});

router.get('/:id/friends', async (req, res) => {
  const userId = u(req.params.id);
  if (!userId) return res.status(400).json({ error: 'Invalid user ID' });
  const user = await db.collection('users').findOne({ _id: userId }, { projection: { friends: 1 } });
  if (!user || !user.friends) return res.json([]);
  const friends = await db.collection('users').find({ _id: { $in: user.friends.map(u) } }, { projection: { password: 0 } }).toArray();
  res.json(friends);
});

router.post('/friend/request/:id', async (req, res) => {
  if (!req.session?.uid) return res.status(401).json({ error: 'Not authenticated' });
  const me = u(req.session.uid);
  const target = u(req.params.id);
  if (!me || !target) return res.status(400).json({ error: 'Invalid user ID' });
  await db.collection('users').updateOne({ _id: target }, { $addToSet: { requests: me } });
  res.json({});
});

router.get('/me/requests', async (req, res) => {
  if (!req.session?.uid) return res.status(401).json({ error: 'Not authenticated' });
  const me = u(req.session.uid);
  const doc = await db.collection('users').findOne({ _id: me }, { projection: { requests: 1 } });
  if (!doc?.requests || doc.requests.length === 0) return res.json([]);
  const list = await db.collection('users').find({ _id: { $in: doc.requests.map(x => (x instanceof ObjectId ? x : u(x))) } }, { projection: { password: 0 } }).toArray();
  res.json(list);
});

router.post('/friend/respond/:id', async (req, res) => {
  if (!req.session?.uid) return res.status(401).json({ error: 'Not authenticated' });
  const me = u(req.session.uid);
  const other = u(req.params.id);
  const { action } = req.body;
  if (!me || !other) return res.status(400).json({ error: 'Invalid user' });

  await db.collection('users').updateOne({ _id: me }, { $pull: { requests: other } });
  if (action === 'accept') {
    await db.collection('users').updateOne({ _id: me }, { $addToSet: { friends: other } });
    await db.collection('users').updateOne({ _id: other }, { $addToSet: { friends: me } });
  }
  res.json({});
});

router.post('/friend/unfriend/:id', async (req, res) => {
  if (!req.session?.uid) return res.status(401).json({ error: 'Not authenticated' });
  const me = u(req.session.uid);
  const other = u(req.params.id);
  if (!me || !other) return res.status(400).json({ error: 'Invalid user' });

  await db.collection('users').updateOne({ _id: me }, { $pull: { friends: other } });
  await db.collection('users').updateOne({ _id: other }, { $pull: { friends: me } });
  res.json({});
});

export default router;