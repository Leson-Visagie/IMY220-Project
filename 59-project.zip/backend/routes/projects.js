import express from 'express';
import multer from 'multer';
import archiver from 'archiver';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { ObjectId } from 'mongodb';
import db from '../db/index.js';

const router = express.Router();
const upload = multer({ dest: 'uploads/', limits: { fileSize: 5 * 1024 * 1024 } });
const __dirname = path.dirname(fileURLToPath(import.meta.url));

const toId = id => {
  try { return id instanceof ObjectId ? id : new ObjectId(id); } catch (e) { return null; }
};

router.get('/', async (req, res) => {
  const query = req.query.user ? { members: { $in: [toId(req.query.user)] } } : {};
  res.json(await db.collection('projects').find(query).toArray());
});

router.post('/', upload.single('image'), async (req, res) => {
  if (!req.session?.uid) return res.status(401).json({ error: 'Not authenticated' });
  const owner = toId(req.session.uid) || req.session.uid;
  const doc = { ...req.body, owner, members: [owner], createdAt: new Date(), status: 'in' };
  if (req.file) doc.image = req.file.filename;
  const ins = await db.collection('projects').insertOne(doc);
  res.json({ id: ins.insertedId });
});

router.get('/:id', async (req, res) => {
  const id = toId(req.params.id);
  if (!id) return res.status(400).json({ error: 'Invalid project ID' });
  res.json(await db.collection('projects').findOne({ _id: id }));
});

router.get('/:id/files', async (req, res) => {
  const id = toId(req.params.id);
  if (!id) return res.status(400).json([]);
  const dir = path.join(__dirname, `../uploads/${id}`);
  if (!fs.existsSync(dir)) return res.json([]);
  res.json(fs.readdirSync(dir));
});

router.get('/:id/file/:path(*)', (req, res) => {
  const id = toId(req.params.id);
  if (!id) return res.status(400).send('Invalid project');
  const file = path.join(__dirname, `../uploads/${id}/${req.params.path}`);
  if (!fs.existsSync(file)) return res.status(404).send('File not found');
  res.sendFile(file);
});


router.post('/:id/checkout', async (req, res) => {
  if (!req.session?.uid) return res.status(401).json({ error: 'Not authenticated' });
  const id = toId(req.params.id);
  const proj = await db.collection('projects').findOne({ _id: id });
  if (proj.status === 'out') return res.status(400).json({ error: 'Already checked out' });

  const user = await db.collection('users').findOne({ _id: toId(req.session.uid) });
  await db.collection('projects').updateOne({ _id: id }, { $set: { status: 'out', holderId: user._id, holderName: user.name } });
  res.json({});
});

router.post('/:id/checkin', upload.array('files'), async (req, res) => {
  if (!req.session?.uid) return res.status(401).json({ error: 'Not authenticated' });
  const id = toId(req.params.id);
  const proj = await db.collection('projects').findOne({ _id: id });
  if (String(proj.holderId) !== req.session.uid) return res.status(403).json({ error: 'Not holder' });

  const dir = path.join(__dirname, `../uploads/${id}`);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  for (const f of req.files) {
    fs.renameSync(f.path, path.join(dir, f.originalname));
  }

  const act = {
    user: toId(req.session.uid),
    msg: req.body.msg,
    files: req.files.map(f => f.originalname),
    at: new Date(),
    version: req.body.version
  };

  await db.collection('projects').updateOne(
    { _id: id },
    { $set: { status: 'in', holderId: null, holderName: null, version: req.body.version }, $push: { activity: act } }
  );
  res.json({});
});

router.get('/:id/download', (req, res) => {
  const id = toId(req.params.id);
  const dir = path.join(__dirname, `../uploads/${id}`);
  if (!fs.existsSync(dir)) return res.status(404).send('No files');

  const archive = archiver('zip', { zlib: { level: 9 } });
  archive.pipe(res);
  archive.directory(dir, false);
  archive.finalize();
});

router.get('/:id/comments', async (req, res) => {
  const id = toId(req.params.id);
  const comments = await db.collection('comments')
    .find({ projectId: id })
    .sort({ createdAt: 1 })
    .toArray();
  

  for (const c of comments) {
    const user = await db.collection('users').findOne({ _id: toId(c.userId) }, { projection: { name: 1 } });
    c.userName = user?.name || 'Unknown';
  }
  res.json(comments);
});

router.post('/:id/comments', async (req, res) => {
  const id = toId(req.params.id);
  if (!req.session?.uid) {
    return res.status(401).json({ error: 'Not authenticated' });
  }

  const comment = {
    projectId: id,
    userId: toId(req.session.uid),
    text: req.body.text,
    createdAt: new Date()
  };

  const result = await db.collection('comments').insertOne(comment);
  comment._id = result.insertedId;

  
  const user = await db.collection('users').findOne(
    { _id: toId(req.session.uid) },
    { projection: { name: 1 } }
  );
  comment.userName = user?.name || 'Unknown';

  res.json(comment);
});

router.get('/:id/members', async (req, res) => {
  const id = toId(req.params.id);
  if (!id) return res.status(400).json({ error: 'Invalid project ID' });

  const project = await db.collection('projects').findOne(
    { _id: id },
    { projection: { members: 1 } }
  );

  if (!project) return res.status(404).json({ error: 'Project not found' });

  const members = await db.collection('users')
    .find(
      { _id: { $in: project.members.map(toId) } },
      { projection: { name: 1 } }
    )
    .toArray();

  res.json(members);
});


router.post('/:id/members', async (req, res) => {
  if (!req.session?.uid) return res.status(401).json({ error: 'Not authenticated' });
  
  const id = toId(req.params.id);
  const meId = toId(req.session.uid);
  const { email } = req.body;

  const proj = await db.collection('projects').findOne({ _id: id }, { projection: { members: 1 } });
  if (!proj) return res.status(404).json({ error: 'Project not found' });
  if (!proj.members.map(String).includes(String(meId))) {
    return res.status(403).json({ error: 'You are not a member of this project' });
  }

  const userToAdd = await db.collection('users').findOne({ email }, { projection: { _id: 1, name: 1 } });
  if (!userToAdd) return res.status(404).json({ error: 'User not found' });

  
  const me = await db.collection('users').findOne({ _id: meId }, { projection: { friends: 1 } });
  if (!me.friends || !me.friends.map(String).includes(String(userToAdd._id))) {
    return res.status(400).json({ error: 'You can only add users who are on your friends list.' });
  }

  await db.collection('projects').updateOne({ _id: id }, { $addToSet: { members: userToAdd._id } });
  res.json(userToAdd);
});


router.delete('/:id/members/:userId', async (req, res) => {
  if (!req.session?.uid) return res.status(401).json({ error: 'Not authenticated' });

  const id = toId(req.params.id);
  const meId = toId(req.session.uid);
  const userIdToRemove = toId(req.params.userId);

  const proj = await db.collection('projects').findOne({ _id: id }, { projection: { owner: 1 } });
  if (!proj) return res.status(404).json({ error: 'Project not found' });
  if (String(proj.owner) !== String(meId)) {
    return res.status(403).json({ error: 'Only the project owner can remove members.' });
  }
  if (String(proj.owner) === String(userIdToRemove)) {
    return res.status(400).json({ error: 'Owner cannot be removed. Relinquish ownership first.' });
  }

  await db.collection('projects').updateOne({ _id: id }, { $pull: { members: userIdToRemove } });
  res.json({ message: 'Member removed' });
});


router.post('/:id/owner', async (req, res) => {
  if (!req.session?.uid) return res.status(401).json({ error: 'Not authenticated' });

  const id = toId(req.params.id);
  const meId = toId(req.session.uid);
  const { userId } = req.body; 
  const newOwnerId = toId(userId);

  if (!newOwnerId) return res.status(400).json({ error: 'Invalid new owner ID' });

  const proj = await db.collection('projects').findOne({ _id: id }, { projection: { owner: 1, members: 1 } });
  if (!proj) return res.status(404).json({ error: 'Project not found' });
  if (String(proj.owner) !== String(meId)) {
    return res.status(403).json({ error: 'Only the project owner can do this.' });
  }
  if (!proj.members.map(String).includes(String(newOwnerId))) {
    return res.status(400).json({ error: 'New owner must be a member of the project.' });
  }

  await db.collection('projects').updateOne({ _id: id }, { $set: { owner: newOwnerId } });
  res.json({ message: 'Ownership transferred' });
});


export default router;