import express from 'express';
import db from '../db/index.js';
const router = express.Router();

router.get('/', async (req, res) => {
  const q = req.query.q || '';
  const users = await db.collection('users').find({
    $or: [
      { name: { $regex: q, $options: 'i' } },
      { email: { $regex: q, $options: 'i' } }
    ]
  }, { projection: { password: 0 } }).limit(20).toArray();

  const projects = await db.collection('projects').find({
    $or: [
      { name: { $regex: q, $options: 'i' } },
      { description: { $regex: q, $options: 'i' } },
      { hashtags: { $in: [q] } }
    ]
  }).limit(20).toArray();

  res.json({ users, projects });
});

export default router;