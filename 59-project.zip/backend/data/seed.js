import { ObjectId } from 'mongodb';
import db from '../db/index.js';


console.log('Clearing existing collections...');
await db.collection('users').deleteMany({});
await db.collection('projects').deleteMany({});
await db.collection('comments').deleteMany({});
await db.collection('projectTypes').deleteMany({});
console.log('Collections cleared.');


console.log('Seeding project types...');
await db.collection('projectTypes').insertMany([
  { name: 'Web Application' },
  { name: 'Mobile Application' },
  { name: 'Library' },
  { name: 'Framework' },
  { name: 'Game' },
]);
console.log('Project types seeded.');


console.log('Seeding 8 users...');
const baseUsers = [
  { _id: new ObjectId(), email: 'test@test.com', password: 'test1234', name: 'Test User', bio: 'I love JS', work: 'TUKS', contact: 'test@tuks.ac.za', friends: [], requests: [] },
  { _id: new ObjectId(), email: 'alice@tuks.ac.za', password: 'alice', name: 'Alice', bio: 'React fan', work: 'TUKS', contact: 'alice@tuks.ac.za', friends: [], requests: [] },
  { _id: new ObjectId(), email: 'bob@tuks.ac.za', password: 'bob', name: 'Bob', bio: 'Backend guru', work: 'TUKS', contact: 'bob@tuks.ac.za', friends: [], requests: [] },
  { _id: new ObjectId(), email: 'carol@tuks.ac.za', password: 'carol', name: 'Carol', bio: 'Mobile dev', work: 'TUKS', contact: 'carol@tuks.ac.za', friends: [], requests: [] },
  { _id: new ObjectId(), email: 'dave@tuks.ac.za', password: 'dave', name: 'Dave', bio: 'AI enthusiast', work: 'TUKS', contact: 'dave@tuks.ac.za', friends: [], requests: [] },
  { _id: new ObjectId(), email: 'eve@tuks.ac.za', password: 'eve', name: 'Eve', bio: 'Security researcher', work: 'TUKS', contact: 'eve@tuks.ac.za', friends: [], requests: [] },
  { _id: new ObjectId(), email: 'frank@tuks.ac.za', password: 'frank', name: 'Frank', bio: 'Designer', work: 'TUKS', contact: 'frank@tuks.ac.za', friends: [], requests: [] },
  { _id: new ObjectId(), email: 'grace@tuks.ac.za', password: 'grace', name: 'Grace', bio: 'QA Engineer', work: 'TUKS', contact: 'grace@tuks.ac.za', friends: [], requests: [] }
];
await db.collection('users').insertMany(baseUsers);
console.log('Users seeded.');


console.log('Setting up friends for test@test.com...');
const testUser = baseUsers[0];
const alice = baseUsers[1];
const bob = baseUsers[2];

await db.collection('users').updateOne(
  { _id: testUser._id },
  { $set: { friends: [alice._id, bob._id] } }
);
await db.collection('users').updateOne(
  { _id: alice._id },
  { $set: { friends: [testUser._id] } }
);
await db.collection('users').updateOne(
  { _id: bob._id },
  { $set: { friends: [testUser._id] } }
);
console.log('Friends set up.');


console.log('Seeding 10 projects...');
const projects = [];
const sampleHashtags = [
  ['react', 'web', 'js'],
  ['python', 'ai', 'data'],
  ['java', 'mobile', 'android'],
  ['swift', 'ios'],
  ['csharp', 'game', 'unity'],
];
const types = (await db.collection('projectTypes').find({}).toArray()).map(t => t.name);

for (let i = 0; i < 10; i++) {
  
  const owner = (i === 0) ? testUser._id : baseUsers[i % baseUsers.length]._id;
  
 
  const members = [owner];
  if (i > 1) { 
    members.push(baseUsers[(i + 1) % baseUsers.length]._id);
    members.push(baseUsers[(i + 2) % baseUsers.length]._id);
  }

  const proj = {
    _id: new ObjectId(),
    name: `Project-${i + 1}`,
    description: `Sample project ${i + 1} description.`,
    owner,
    members: [...new Set(members)], 
    hashtags: sampleHashtags[i % sampleHashtags.length],
    type: types[i % types.length],
    version: '1.0.0',
    image: '',
    status: 'in',
    holderId: null,
    holderName: null,
    activity: [],
    createdAt: new Date(Date.now() - (i * 1000 * 60 * 60 * 24)), 
  };
  projects.push(proj);
}
await db.collection('projects').insertMany(projects);
console.log('Projects seeded.');


console.log('Seeding 20 check-ins...');
const activities = [];


const testUserCheckin = {
  projId: projects[1]._id, 
  act: {
    user: testUser._id,
    msg: `Test user's check-in on Project-2`,
    files: [`readme.md`],
    at: new Date(Date.now() - (1000 * 60 * 60)),
    version: `1.0.1`
  }
};
activities.push(testUserCheckin);


for (let i = 0; i < 19; i++) {
  const user = baseUsers[i % baseUsers.length];
  const proj = projects[(i + 2) % projects.length]; 
  const act = {
    user: user._id,
    msg: `Check-in ${i + 1} for ${proj.name} by ${user.name}`,
    files: [`file-${i + 1}.txt`, `main.js`],
    at: new Date(Date.now() - (i * 1000 * 60 * 60)),
    version: `1.0.${i + 2}` 
  };
  activities.push({ projId: proj._id, act });
}


for (const item of activities) {
  await db.collection('projects').updateOne(
    { _id: item.projId },
    { $push: { activity: item.act } }
  );
}
console.log('Check-ins seeded.');

console.log('--- SEEDING COMPLETE ---');
process.exit(0);