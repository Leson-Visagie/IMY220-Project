import { MongoClient } from 'mongodb';
const client = new MongoClient(process.env.MONGO_URL || 'mongodb://mongo:27017');
await client.connect();
export default client.db('imy220');