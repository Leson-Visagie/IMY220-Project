BUILD & RUN
1. docker-compose up --build
2. Open http://localhost:3000

STRUCTURE
/backend   – Express + Mongo API
/frontend  – React + React-Router
/export    – Mongo seed data